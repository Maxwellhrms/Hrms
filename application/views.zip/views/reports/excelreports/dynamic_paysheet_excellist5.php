<?php
 //echo "<pre>------>";print_r($footer_column_names);die;
    if(count($common)>0){ 
    
    ?>
    
                    <div class="row" style="margin-top: 10px;">
                        <div class="col-sm-12">
                            <div class="card mb-0">					
                                <div class="card-header">
									<h4 class="card-title mb-0">Preview List</h4>
								</div>
                                <div class="card-body">	
									<div class="table-responsive">
                                        <table class="datatable table table-stripped mb-0" id="dataTables-example2">
											<thead>
												<tr>
                                                    <?php for($i=0; $i < count($headings); $i++) { ?>
												        	<th><?php echo str_replace('_', ' ' ,strtoupper($headings[$i]) ) ?></th>
                                                    <?php } ?>
                                                </tr>
											</thead>
                                            <tbody>
                                                <?php 
												
                                                //for($i=0; $i<sizeof($common);$i++) { 
                                                         //print_r($common[$i]);exit;
                                                        //foreach($common[$i] as $key =>$val){ 
                                                             //echo $val;exit;
                                                                    //echo $val;
																//}  
																// } ?>   
                                            </tbody>
                                            <?php
											//print_r($userdata['month_year']);die;
                                            if(count($footer_column_names) > 0){
                                                echo "<tfoot>";
                                                echo "<tr>";
												$month_year=$userdata['month_year'];
                                                foreach($footer_column_names as $key => $value){
													//echo "<pre>";  echo $key."-->".$value;
													if($key=='0')
													{$value='1';
													}
													if($key=='1')
													{$value=$month_year;
													}
													if($key=='11')
													{$value='15-'.$month_year;
													}
													if($key=='12')
													{$value='<input type="date" name="paiddate" id="paiddate" />';
													}
													if($key=='13')
													{$value='<input type="file" name="ecr_upload" id="ecr_upload" /><br>
														<button type="button" id="upload_btn" >upload</button>';
													}
													if($key=='14')
													{
														
															 $sql5 = " SELECT * FROM ecr_attachments where attndyear = '$month_year' ";
															 $result5 = $this->db->query($sql5);
															  $lastrowofareq5=$result5->result_array();
															  $oldLead_id5=$result5->num_rows() ;
															  if($oldLead_id5>0){ 
																$file_path=$lastrowofareq5['0']['file_path'];
															  }
															  $value="<a href='$file_path' target='_blank'>View File</a>";
													}
													
                                                    echo "<th>$value</th>";
                                                    
                                                }
                                                echo "</tr>";
                                                echo "</tfoot>";    
                                            }
                                            ?>
                                            
										</table>
									</div>
								</div>
                            </div>
                        </div>
                    </div>
 <?php }else{
     echo 'No Data Exist'; exit;
 } ?>
 <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function() {
    $('#upload_btn').on('click', function(e) {
        e.preventDefault();

        var file_data = $('#ecr_upload').prop('files')[0];
		var attndyear = $('#attndyear').val();
		var paiddate = $('#paiddate').val();
        var form_data = new FormData();
        form_data.append('ecr_upload', file_data);
		form_data.append('attndyear', attndyear);
		form_data.append('paiddate', paiddate);

        $.ajax({
            url: '<?= base_url("export/do_upload") ?>', // Update to your controller/method
            type: 'POST',
            data: form_data,
            contentType: false,
            processData: false,
            success: function(response) {
                alert(response); // Handle success
            },
            error: function(xhr, status, error) {
                alert("Upload failed: " + xhr.responseText);
            }
        });
    });
});
</script>

